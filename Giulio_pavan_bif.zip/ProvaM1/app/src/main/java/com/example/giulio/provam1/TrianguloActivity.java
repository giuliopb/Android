package com.example.giulio.provam1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class TrianguloActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etBase;
    private EditText etAltura;
    private Button btnAvanTriangulo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triangulo);

        etBase = (EditText) findViewById(R.id.etBase);
        etAltura = (EditText) findViewById(R.id.etAltura);
        btnAvanTriangulo = (Button) findViewById(R.id.btnAvanTriangulo);
    }


    @Override
    public void onClick(View v) {
        if (etBase.getText().toString().isEmpty()) {
            etBase.setError("digite um numero");
        } else if (etAltura.getText().toString().isEmpty()) {
            etAltura.setError("digite um numero");
        } else {

            Double intBase = Double.parseDouble(etBase.getText().toString());
            Double intAltura = Double.parseDouble(etAltura.getText().toString());

            double resultado = (intAltura*intBase)/2;

            Intent intent = new Intent(this, ResultadoQuadrado.class);
            intent.putExtra("resultado", resultado);
            startActivity(intent);
        }
    }
}
