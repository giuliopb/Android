package com.example.giulio.provam1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CirculoActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etRaio;
    private Button btnAvancarRaio;
    public static final double PI = 3.141592653589793d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_circulo);

        etRaio = (EditText) findViewById(R.id.etRaio);
        btnAvancarRaio = (Button) findViewById(R.id.btnAvancarRaio);

    }

    @Override
    public void onClick(View v) {

        if(etRaio.getText().toString().isEmpty()){
            etRaio.setError("digite um numero");
        }
        else{
            Double raio = Double.parseDouble(etRaio.getText().toString());
            double resultado = Math.PI * (raio*raio);

            Intent intent = new Intent(this, ResultadoQuadrado.class);
            intent.putExtra("resultado",resultado);
            startActivity(intent);
        }

    }
}
