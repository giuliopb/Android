package com.example.giulio.provam1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class ResultadoQuadrado extends AppCompatActivity implements View.OnClickListener {
    private EditText etResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado_quadrado);

        etResultado = (EditText)findViewById(R.id.etResultado);

        Intent intent = getIntent();
        Double resultado = intent.getDoubleExtra("resultado",0);

        etResultado.setText("area: " + resultado);
    }
    public void onClick(View v) {
        Intent i=new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }
}
